<form class="search-form" method="get" action="<?php echo home_url('/'); ?>">
    <input type="search" name="s" id="s" size="15" placeholder="Search the website">
    <input type="submit" value="&#128269;">
</form>