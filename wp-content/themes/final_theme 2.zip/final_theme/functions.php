<?php
    add_theme_support( 'html5', array( 'comment-list', 'comment-form', 'search-form', 'gallery', 'caption', 'style', 'script','post-thumbnails', 'post'));
    add_theme_support( 'title-tag' );
    function linked_assets(){
        wp_enqueue_style('main', get_stylesheet_uri());
    }
    add_action('wp_enqueue_scripts', 'linked_assets');
    function menu(){
        register_nav_menu('header-menu', 'Main Menu (Header)');
    }
?>
