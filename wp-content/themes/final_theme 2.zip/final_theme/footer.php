</main>
   <?php wp_footer(); ?> 
   <footer>
      <div>
         <a href="https://www.facebook.com/shangrila">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/facebook.svg" width="50" height="50" alt="facebook"/>
         </a>
         <a href="https://www.instagram.com/shangrilahotels/?hl=en">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/instagram.svg" width="50" height="50" alt="instagram"/>
         </a>
         <a href="https://twitter.com/ShangriLaHotels">
            <img src="<?php echo get_stylesheet_directory_uri(); ?>/images/twitter.svg" width="50" height="50" alt="twitter" />
         </a>
      </div>
      <div>
         <small>Photographs by Easa Shamih, Raj Deutunder, and Paryitno under a Creative Commons Attribution 2.0 Generic (CC BY 2.0) license</small>
      </div>
   </footer>
</body>
</html>