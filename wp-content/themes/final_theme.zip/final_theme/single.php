<?php 
// this is the page to show individual 'Post' content
get_header()
 ?>
 <div id="single">
 <article>
    <?php 
    if(have_posts()){
        while(have_posts()){
            the_post();
            the_title('<h2>','</h2>');
            echo "<div class='post_authoring'>";
            echo "<figure class='post_image'>" . get_the_post_thumbnail(get_the_ID(), 'thumbnail') . "</figure>";
            echo "<div>";
            echo '<span class="post_author" >Posted by <strong>' . get_the_author() . '</strong> on ' .  '</span>';
            the_date();
            echo "</div>";
            echo "</div>";
            // echo get_the_post_thumbnail(get_the_ID(), 'thumbnail');
            // echo the_date();
            
            // echo "<figure class='post_image'>" . get_the_post_thumbnail(get_the_ID(), 'thumbnail') . "</figure>";
            // the_author();
            // echo '<p class="author">Posted by ' . get_the_author() . ' on ' . the_date() . '</p>' ;
            // the_date('','<p class="date">Posted on ', '</p>');
            echo "<div class='post_content'>";
            the_content();
            echo "</div>";

            // the_excerpt();
            // the_permalink();
            // echo '<a href="'.get_the_permalink().'">Read More</a>';
        }
    }
    comments_template();
    ?>
</article>
<?php get_sidebar(); ?>
<!-- }
?> -->
</div>


<?php get_footer()?>
