<?php get_header() ?>
<h2>This is the search result for &ldquo; <?php echo $_GET['s']?>&rdquo; </h2>
    <?php 
    if(have_posts()){
        while(have_posts()){
            the_post();
            the_title('<h2>','</h2>');
            the_date('','<p class="date">Posted on ', '</p>');
            // the_content();
            the_excerpt();
            // the_permalink();
            echo '<a href="'.get_the_permalink().'">Read More</a>';
        }
    }else{
        echo "<p>No results found for the above search query</p>";
    }
    ?>

<?php get_footer()?>