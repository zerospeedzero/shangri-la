<?php 
// this is the page to show single page content content
get_header()
 ?>
 <div id="page">
    <?php 
    if(have_posts()){
        while(have_posts()){
            the_post();
            // Heading overlay
            the_title('<h1>','</h1>');
            
            // the_author();
            // echo '<p class="author">Posted by '.get_the_author().'</p>';
            echo "<div class='main_container'>";
            the_content();
            echo "</div>";
            // the_excerpt();
            // the_permalink();
            // echo '<a href="'.get_the_permalink().'">Read More</a>';
        }
    }
    ?>
</div>

<?php get_footer()?>
