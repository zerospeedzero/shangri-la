<?php if(comments_open()){ ?>
<section id="comments">
    <?php 
    echo '<h3>';
    comments_number('No comment on this post', 'One Comment for this post', '% comments');
    echo '</h3>';
    if(have_comments()){
        echo '<ol>';
        // display the comments for that post if we laready have comments
        wp_list_comments(array(
            'style'=> 'ol',
            'avatar_size'=> 64,
            'reverse_top_level'=> 'true'

        ));
        echo '</ol>';
    }
    comment_form();
    ?>
</section>

<?php } else if(!comments_open()){
    echo '<h3>Comments are closed for this post</h3>';
}?>