<aside>
  <!-- <?php dynamic_sidebar('blog-sidebar')?> -->
  <?php
    if(is_single()) {
      dynamic_sidebar('blog-sidebar');
    // } else if (is_page()) {
    } else {
      dynamic_sidebar('post-sidebar');
    }
  ?>

</aside>